#ifndef _28BYJ_48_H
#define _28BYJ_48_H

void Motor_Init(void);
void Motor_Ctrl(uint16_t angle,uint8_t direction);

#endif
