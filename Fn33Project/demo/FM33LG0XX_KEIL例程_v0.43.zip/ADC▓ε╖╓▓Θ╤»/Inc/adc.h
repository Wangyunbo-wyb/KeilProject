#ifndef __ADC_H__
#define __ADC_H__

#include "fm33lg0xx_fl.h"


extern int32_t GetDifferentialChannelVoltage_POLL(uint32_t channel);

#endif
